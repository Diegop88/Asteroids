package com.diegop.asteroides;

public interface JoystickClickedListener {
        public void OnClicked();
        public void OnReleased();
}